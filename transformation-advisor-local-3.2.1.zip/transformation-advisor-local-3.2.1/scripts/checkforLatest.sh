#!/usr/bin/env bash

#---------------------------------------------
#Licensed Materials - Property of IBM
#(C) Copyright IBM Corporation 2021
#---------------------------------------------
#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi


###tag the UI image to be latest
#get the tag version and image name
uiID=`docker images | grep icr.io/appcafe/transformation-advisor-ui | awk '{print $3}'`
tag=`docker images | grep transformation-advisor-ui | awk '{print $2}'`
imageName=`docker images | grep transformation-advisor-ui | awk '{print $1}'`

##tag the image to be latest
docker tag $imageName:$tag $imageName:latest



while :; do
printf "."
sleep 1
done &
trap "kill $!" EXIT 2>/dev/null #Die with parent if we die prematurely
disown
docker pull icr.io/appcafe/transformation-advisor-ui:latest > ./latest.txt
echo ""
kill $! && trap " " EXIT 2>/dev/null

###checking if to use docker or podman

if [[ $TA_LOCAL_TEMP_DOCKER_INSTALL = true ]]; then

 if $(grep -q "Image is up to date" ./latest.txt); then
echo "Status"
echo "------------------------------------------------------------------------------------------------------"
echo "Transformation Advisor is up to date."
docker rmi -f $imageName:latest >./uninstall.txt
else
echo "Status"
echo "------------------------------------------------------------------------------------------------------"
echo "A newer version of Transformation Advisor is available. Please select option 2 or 3 to uninstall. "
echo "Then download the latest Transformation Advisor LOCAL zip (http://ibm.biz/cloudta) and install it."
    docker rmi -f $imageName:latest >./uninstall.txt


    rm -rf ./uninstall.txt
 fi

rm -rf ./latest.txt

else

 if  `grep -q "$uiID" ./latest.txt`; then
echo "Status"
echo "------------------------------------------------------------------------------------------------------"
echo "Transformation Advisor is up to date."
docker rmi -f $imageName:latest >./uninstall.txt
 else
echo "Status"
echo "------------------------------------------------------------------------------------------------------"
echo "A newer version of Transformation Advisor is available. Please select option 2 or 3 to uninstall. "
echo "Then download the latest Transformation Advisor LOCAL zip (http://ibm.biz/cloudta) and install it."
docker rmi -f $imageName:latest >./uninstall.txt

 fi

fi
