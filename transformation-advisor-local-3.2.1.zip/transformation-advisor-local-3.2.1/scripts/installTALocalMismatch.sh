#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

source ./.security_config

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi



source ./installHelper.sh
source ./findHost.sh

# clean the env file
./copy_back_files.sh

replaceHost
sleep 1

## start docker compose
startDockerCompose



# set the protocol
PROTOCOL=http
# translate into lower case
TA_AUTH_ENABLE_TLS_lower_case=$(echo "$TA_AUTH_ENABLE_TLS" | tr '[:upper:]' '[:lower:]')

if [[ $TA_AUTH_ENABLE_TLS_lower_case == 'true' ]]; then
	PROTOCOL=https
fi

# this will print dots like ... in a background job
source ./helper.sh
showConfiguringTA

# grab the internal UI port to find out the external UI port, this port was dynamic assigned in the past
ui_port=$TA_LOCAL_INTERNAL_UI_PORT
uiID=$(docker ps | grep transformation-advisor-ui | awk '{print $1}')
taVersion=$(docker inspect $uiID | grep version | tail -n 1 | awk -F : '{print $2}' | sed 's/^.//' | tr -d '"')

# this will kill the dots generation background job
killBackgroundJob

displayTARunningStatus "$PROTOCOL" "$TA_LOCAL_RUNTIME_HOST_IP" "$ui_port" "$taVersion"
