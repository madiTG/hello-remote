# Created by Huang, Fuguo (aka ken) on 17.1.2022.


function showConfiguringTA () {
	TEMP_WORDING=$1
	if [ -z "$TEMP_WORDING" ]; then
		TEMP_WORDING="Configuring Transformation Advisor.."
	fi

	echo -n $TEMP_WORDING
  while :; do
  	printf "."
  	sleep 1
  done &

	# run kill $! on EXIT signal or on Ctrl+C
	trap "kill $!" EXIT 2>/dev/null #Die with parent if we die prematurely
}

function killBackgroundJob() {
	# remove current job
	disown
	# debugger
	echo ""
	# remove background job, remove overwrite trap, i.e. remove run kill $! on EXIT signal
	kill $! && trap - EXIT 2>/dev/null
}

function displayTARunningStatus() {
	TEMP_PROTOCOL_123=$1
	TEMP_RUNTIME_HOST=$2
	TEMP_UI_PORT_123=$3
	TEMP_TA_VERSION_123=$4
	TEMP_TAG_123=$5

  	echo "Status"
  	echo "------------------------------------------------------------------------------------------------------" "$TEMP_TAG_123"
  	echo "Transformation Advisor ${TEMP_TA_VERSION_123} is available for use at the following URL> ${TEMP_PROTOCOL_123}://${TEMP_RUNTIME_HOST}:${TEMP_UI_PORT_123}"

}