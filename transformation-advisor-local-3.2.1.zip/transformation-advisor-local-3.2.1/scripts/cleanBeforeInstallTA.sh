#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

### you can also set TA_LOCAL_TEMP_PODMAN_INSTALL to true manually, to run this file with podman.
### create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
	shopt -s expand_aliases
	source ./.podman_config
fi

#### Clean up docker ########
#############################

### Get the TA Docker Container IDs

ui=$(docker ps -a | grep transformation-advisor-ui | awk '{print $1}')
couch=$(docker ps -a | grep transformation-advisor-db | awk '{print $1}')
server=$(docker ps -a | grep transformation-advisor-server | awk '{print $1}')
neo4j=$(docker ps -a | grep transformation-advisor-neo4j | awk '{print $1}')

#### Stop All TA Docker Containers

for a in $ui; do
	docker stop $a
done

for b in $couch; do
	docker stop $b
done

for c in $server; do
	docker stop $c
done

for d in $neo4j; do
  docker stop $d
done

#### Remove TA Containers ###################

for e in $ui; do
	docker rm -f $e
done

for f in $couch; do
	docker rm -f $f
done

for g in $server; do
	docker rm -f $g
done

for h in $neo4j; do
  docker rm -f $h
done

#### Remove TA Images #####################

ui_image=$(docker images | grep transformation-advisor-ui | awk '{print $3}')
couch_image=$(docker images | grep transformation-advisor-db | awk '{print $3}')
server_image=$(docker images | grep transformation-advisor-server | awk '{print $3}')
neo4j_image=$(docker images | grep transformation-advisor-neo4j | awk '{print $3}')

# to keep docker images, comment out the following codes

for i in $ui_image; do
	docker rmi -f $i
done

for j in $couch_image; do
	docker rmi -f $j
done

for k in $server_image; do
	docker rmi -f $k
done

for l in $neo4j_image; do
	docker rmi -f $l
done

sleep 5

#######remove the network



# we prioritise to use docker if available
if [[ $TA_LOCAL_TEMP_DOCKER_INSTALL = true ]]; then
	net=`docker network ls | grep ta_local | awk '{print $1}'`
  if [[ ! -z $net ]] ; then
   docker network rm $net
  fi
fi
# assume either docker or podman is available, otherwise should failed in pre-req checking
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
	pod=`docker pod list | grep ta_pod | awk '{print $2}'`
  if [[ ! -z $pod ]] ; then
   docker pod rm $pod
  fi
fi


### Find the hostname and edit the environment files #######
############################################################

source ./findHost.sh
replaceHost


sleep 5
