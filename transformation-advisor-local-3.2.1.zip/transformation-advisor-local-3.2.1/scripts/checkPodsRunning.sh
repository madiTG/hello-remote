#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"

source ./.security_config

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi

function checkUIPodMain {

	for ((i = 0; i < 150; i++)); do
                ui_port=$TA_LOCAL_INTERNAL_UI_PORT
		if [ -z $ui_port ]; then
			echo "Status"
			echo "---------------------------------------------------------------------------------------------------------------------------------"
			echo "Transformation Advisor UI pod could not be started."
			echo "This could indicate an incompatibility issue between the existing environment variables and the new docker images."
			echo "Please uninstall and download the latest transformationAdvisor.zip from http://ibm.biz/cloudta and try again."
			echo ""

			echo "Select the operation....

 1) Stop Transformation Advisor
 2) Uninstall Transformation Advisor (keep database data)
 3) Uninstall Transformation Advisor (remove database data)
 4) Quit."

			read n
			case $n in
			1)
				echo -n "Stopping Transformation Advisor..."
				./stopTransformationAdvisor.sh
				echo "Transformation Advisor processes are stopped."
				;;
			2)
				echo "Uninstalling Transformation Advisor..."
				./cleanUpBeforeInstall.sh
				echo "Finished Uninstalling Transformation Advisor..."
				rm -rf ../.license_accepted
				rm -rf ../logs/*
				./copy_back_files.sh
				;;
			3)
				echo -n "Uninstalling Transformation Advisor..."
				./cleanUpBeforeInstall.sh
				rm -rf ../data
                                rm -rf ../graph_data
				echo "Finished Uninstalling Transformation Advisor..."
				rm -rf ../.license_accepted
				rm -rf ../logs/*
				./copy_back_files.sh
				;;
			4) exit ;;

			esac
			exit

			break
		else
    	break
		fi

	done

}

function checkDBPod {

	for ((i = 0; i < 150; i++)); do
		db_port=$(docker ps |  grep transformation-advisor-db | awk '{print $1}')
		if [ -z $db_port ]; then
			echo "Status"
			echo "---------------------------------------------------------------------------------------------------------------------------------"
			echo "Transformation Advisor couchDB pod could not be started."
			echo "This could indicate that the data directory does not have the correct permissions."
			echo "Run command 'chmod -R ugo+rwx data'."
			echo "Restart the couchDB pod and then the server pod."
			exit
		else
			break
		fi
	done

}

function checkLibertyOnline() {
	#	grab the external port from config
	ta_local_external_liberty_port=$(awk '/TA_EXTERNAL_SERVER_PORT/{print}' .env)



	# if ta_local_external_liberty_port contains <server_port>, e.g.TA_LOCAL_EXTERNAL_SERVER_PORT=<server_port>
	if [[ "$ta_external_liberty_port" == *"<server_port>"* ]]; then
		TA_EXTERNAL_SERVER_PORT=$(docker ps | grep "$TA_LOCAL_INTERNAL_SERVER_PORT" | awk -F "->" '{print $1}' | awk -F ":" '{print $3}')
	else
		# we could simplified to always check docker status to get external liberty port
		# set this to current env
    export "$ta_local_external_liberty_port"

	fi



	url=$PROTOCOL://${TA_LOCAL_RUNTIME_HOST_IP}:${TA_EXTERNAL_SERVER_PORT}/lands_advisor/advisor/healthcheck


	for i in {1..20}
	do
		# use quotes to avoid IP's dots removed
		x=$(curl -s -k "$url" | grep "{\"status\":\"OK\"}")
		# use curl silent mode, and if x is not empty, it means TA war is running


		if [ ! -z "$x" ]; then
			break
		fi
		sleep 5
	done

}
