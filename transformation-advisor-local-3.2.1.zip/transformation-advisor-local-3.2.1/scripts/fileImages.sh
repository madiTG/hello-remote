#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

source ./.configuration

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi


echo "Have you already saved the Transformation Advisor images to a tarball (y/n)?"
read answer
echo ""
if [ $answer == 'y' ] || [ $answer == 'Y' ]; then

	while :; do
		echo "Enter filename location (eg, /root/ta/ta-images.tar.gz)"
		read -r location
		location="${location:=/root/ta/ta-images.tar.gz}"

		if ! [[ "${location:0:1}" == / || "${location:0:2}" == ~[/a-z] ]]; then
			location=$PWD/../$location
		fi

		if [[ -f $location ]] && [[ $location = *.gz ]]; then
			break
		else
			echo "File ($location) does not exist. Try again."
		fi
	done

	echo -n "Loading the Transformation Advisor images.."
	while :; do
		printf "."
		sleep 1
	done &
	trap "kill $!" EXIT 2>/dev/null #Die with parent if we die prematurely
	disown
	gunzip -c "$location" | docker load
	sleep 5
	echo ""
	kill $! && trap " " EXIT 2>/dev/null

	echo "Finished uploading the Transformation Advisor images"
	echo "Starting Transformation Advisor....."
	./installTALocalAirGapped.sh
else

	echo "How to create the ta-images.tar.gz file."
	echo "--------------------------------------------"
	echo "On a system that has docker or podman installed and has internet connectivity, pull the TA images."
	echo "Then, save the images to a gzip'd tar ball."
	echo ""
	echo "docker / podman pull $TA_LOCAL_CONFIG_COUCH_IMAGE"
	echo "docker / podman pull $TA_LOCAL_CONFIG_UI_IMAGE"
	echo "docker / podman pull $TA_LOCAL_CONFIG_SERVER_IMAGE" 
        echo "docker / podman pull $TA_LOCAL_CONFIG_NEO4J_IMAGE"
	echo ""
	echo "If you using docker, run the command below"
	echo ""
	echo "docker save $TA_LOCAL_CONFIG_COUCH_IMAGE $TA_LOCAL_CONFIG_UI_IMAGE $TA_LOCAL_CONFIG_SERVER_IMAGE $TA_LOCAL_CONFIG_NEO4J_IMAGE | gzip > ta-images.tar.gz"
	echo ""
	echo "If you using podman, run the command below"
	echo ""
	echo "podman save -m $TA_LOCAL_CONFIG_COUCH_IMAGE $TA_LOCAL_CONFIG_UI_IMAGE $TA_LOCAL_CONFIG_SERVER_IMAGE $TA_LOCAL_CONFIG_NEO4J_IMAGE | gzip > ta-images.tar.gz"
	echo ""
	echo "Transfer the file to the target server and run the launchTransformationadvisor script."
	echo "Choose the option to work in an air gapped environment and you will be prompted to enter the location of the tarball containing the images."
	echo ""

	rm -rf ../.license_accepted

fi
