#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

source ./.security_config

###create the podman/docker alias
source ./createPodmanAlias.sh
createPodmanAlias

source ./enableSecurity.sh
# enable security environment, if conditions are met.
importSecurityEnv
source ./checkPodsRunning.sh

echo ""
echo "Prerequisites"
echo "------------------------------------------------------------------------------------------------------"

# if does not contain "command not found", we have docker
if [[ $TA_LOCAL_TEMP_DOCKER_INSTALL = true ]]; then
	echo "Docker installed."
	echo ""
	echo ""
elif [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
	echo "Podman installed."
	echo ""
	echo ""
fi

			cmd=$(docker ps | grep transformation-advisor-server | awk '{print $1}')
			cmd1=$(docker ps | grep transformation-advisor-ui | awk '{print $1}')
			cmd2=$(docker ps | grep transformation-advisor-db | awk '{print $1}')
			cmd6=$(docker ps | grep transformation-advisor-neo4j | awk '{print $1}')

			cmd3=$(docker images | grep transformation-advisor-server | awk '{print $1}')
			cmd4=$(docker images | grep transformation-advisor-ui | awk '{print $1}')
			cmd5=$(docker images | grep transformation-advisor-db | awk '{print $1}')
			cmd7=$(docker images | grep transformation-advisor-neo4j | awk '{print $1}')

			if [[ -z $cmd3 ]] && [[ -z $cmd4 ]] && [[ -z $cmd5 ]] && [[ -z $cmd7 ]]; then
				echo "Status"
				echo "------------------------------------------------------------------------------------------------------"
				echo "Transformation Advisor images are not pulled..."
				echo "Please select option 1 to install Transformation Advisor or option 7 if working in an Air Gapped Environment."
			fi

			if [[ ! -z $cmd3 ]]; then
				if [ -z $cmd ] || [ -z $cmd1 ] || [ -z $cmd2 ] || [ -z $cmd6 ]; then
					echo "Status"
					echo "------------------------------------------------------------------------------------------------------"
					echo "Transformation Advisor images installed but not running."
					echo "Please select option 5 to start Transformation Advisor."
				else
					# if TA is running, display the status

					# set the protocol, reset the protocol, as startDockerCompose set to something else
          PROTOCOL=http
          # translate into lower case
          TA_AUTH_ENABLE_TLS_lower_case=$(echo "$TA_AUTH_ENABLE_TLS" | tr '[:upper:]' '[:lower:]')

          if [[ $TA_AUTH_ENABLE_TLS_lower_case == 'true' ]]; then
          	PROTOCOL=https
          fi

          # this will print dots like ... in a background job
          source ./helper.sh
          showConfiguringTA "Checking Transformation Status.."

          # grab the internal UI port to find out the external UI port, this port was dynamic assigned in the past
          ui_port=$TA_LOCAL_INTERNAL_UI_PORT
          uiID=$(docker ps | grep transformation-advisor-ui | awk '{print $1}')
          taVersion=$(docker inspect $uiID | grep version | tail -n 1 | awk -F : '{print $2}' | sed 's/^.//' | tr -d '"')

          ########### testing for ui, couchDB and liberty containers are running #######
          checkUIPodMain
          checkDBPod
          checkLibertyOnline
          ##############################################################################

          # this will kill the dots generation background job
          killBackgroundJob

          displayTARunningStatus "$PROTOCOL" "$TA_LOCAL_RUNTIME_HOST_IP" "$ui_port" "$taVersion"
				fi
			fi

			echo ""
			echo ""
			echo ""
			echo "Select the operation.......

1) Install Transformation Advisor
2) Uninstall Transformation Advisor (keep database data)
3) Uninstall Transformation Advisor (remove database data)
4) Stop Transformation Advisor
5) Start Transformation Advisor
6) Check for latest Transformation Advisor
7) Working in an Air Gapped Environment
8) Quit "

			read n
			case $n in
			1)
				echo -n "Installing Transformation Advisor..."
				./cleanUpBeforeInstall.sh
				./installTALocal.sh
				sleep 3
				./renameDockerName.sh &>/dev/null
				;;
			2)
				echo -n "Uninstalling Transformation Advisor..."
				./cleanUpBeforeInstall.sh
				echo "Finished Uninstalling Transformation Advisor..."
				rm -rf ../.license_accepted
				rm -rf ../logs/*
				./copy_back_files.sh
				;;
			3)
				echo -n "Uninstalling Transformation Advisor..."
				./cleanUpBeforeInstall.sh; rm -rf ../data; rm -rf ../graph_data;
				echo "Finished Uninstalling Transformation Advisor..."
				rm -rf ./.neo4j_pass
				rm -rf ../.license_accepted
				rm -rf ../logs/*
				./copy_back_files.sh
				;;
			4)
				echo -n "Stopping Transformation Advisor..."
				./stopTransformationAdvisor.sh

				echo "Transformation Advisor processes are stopped."
				;;
			5)
				echo "Starting Transformation Advisor..."
				./startTA.sh
				;;
			6)
				echo -n "Checking if newer version of Transformation Advisor is available..."
				./checkforLatest.sh
				echo ""
				;;
			7) ./fileImages.sh ;;
			8) exit ;;
			esac
