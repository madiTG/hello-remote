#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts to close down non-essential egress ports in the docker network
#This script assumes the default cni-podman0 output is bineg used. Update the script to the appropriate value if that is not the case
sudo iptables -I CNI-FORWARD -o cni-podman0 -j DROP
sudo iptables -I CNI-FORWARD -o cni-podman0 -p tcp -m multiport --dport 53,80,443,3000,3443,9080,9443,5984,6984,7687 -j ACCEPT
sudo iptables -I CNI-FORWARD -o cni-podman0 -p tcp -m multiport --sport 53,80,443,3000,3443,9080,9443,5984,6984,7687 -j ACCEPT
sudo iptables -I CNI-FORWARD -o cni-podman0 -p udp --sport 53 -j ACCEPT
sudo iptables -I CNI-FORWARD -o cni-podman0 -p udp --dport 53 -j ACCEPT