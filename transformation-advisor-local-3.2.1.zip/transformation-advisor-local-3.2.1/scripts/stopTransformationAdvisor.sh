#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi


### Get the TA Docker Container IDs

ui=$(docker ps -a | grep transformation-advisor-ui | awk '{print $1}')
couch=$(docker ps -a | grep transformation-advisor-db | awk '{print $1}')
server=$(docker ps -a | grep transformation-advisor-server | awk '{print $1}')
graph=$(docker ps -a | grep transformation-advisor-neo4j | awk '{print $1}')

#### Stop All TA Docker Containers

while :; do
	printf "."
	sleep 1
done &
trap "kill $!" EXIT 2>/dev/null #Die with parent if we die prematurely
disown

for a in $ui; do
	docker stop $a >../logs/uninstall_$(date +"%Y%m%d_%H%M%S").log
done

for b in $couch; do
	docker stop $b >../logs/uninstall_$(date +"%Y%m%d_%H%M%S").log
done

for c in $server; do
	docker stop $c >../logs/uninstall_$(date +"%Y%m%d_%H%M%S").log
done

for d in $graph; do
	docker stop $d >../logs/uninstall_$(date +"%Y%m%d_%H%M%S").log
done


echo ""
kill $! && trap " " EXIT 2>/dev/null
