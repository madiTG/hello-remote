function  acceptLicense {
echo "

1) I have read and agreed to the license agreements
2) Don't accept the license agreements"

read n
case $n in
 1) ./scripts/launchTransformationAdvisor.sh;;

 2) rm -rf ./.license_accepted
 exit ;;

 esac
 exit

}

function licenseType {

echo "View the licenses in the link below and select from the menu which license you are installing this product under"
echo ""
echo "https://www.ibm.com/docs/en/cta?topic=started-license-information"
echo ""

echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------"

echo "

1) IBM Cloud Transformation Advisor 3.2.0 (Evaluation) - L-NHON-CF6JNQ 
2) IBM WebSphere Hybrid Edition 5.1 - L-AMIK-C92MN6 
3) IBM Cloud Foundry Migration Runtime 4.1.2 - L-DLOZ-C5UHZE 
4) IBM Cloud Pak for Integration 2021.4.1- L-RJON-C7QG3S 
5) IBM Cloud Pak for Integration Limited Edition 2021.4.1 -  L-RJON-C7QFZX 
6) IBM Cloud Pak for Applications 5.1 - L-AMIK-BYM26G 
7) IBM Cloud Pak for Applications Limited Edition 5.1 - L-AMIK-BYM2RQ
8) IBM WebSphere Application Server for z/OS 8.5.5 - L-CTUR-C7K3YZ
9) IBM WebSphere Application Server for z/OS 9.0.5 -L-CTUR-CBPUER"

read l

case $l in

1) touch ./.license_accepted
   echo "IBM Cloud Transformation Advisor 3.2.0 (Evaluation) - L-NHON-CF6JNQ" > ./.license_accepted;;
2) touch ./.license_accepted
   echo "IBM WebSphere Hybrid Edition 5.1 - L-AMIK-C92MN6" > ./.license_accepted;;
3) touch ./.license_accepted
   echo "IBM Cloud Foundry Migration Runtime 4.1.2 - L-DLOZ-C5UHZE" > ./.license_accepted;;
4) touch ./.license_accepted
   echo "IBM Cloud Pak for Integration 2021.4.1- L-RJON-C7QG3S" > ./.license_accepted;;
5) touch ./.license_accepted
   echo "IBM Cloud Pak for Integration Limited Edition 2021.4.1 -  L-RJON-C7QFZX" > ./.license_accepted;;
6) touch ./.license_accepted
   echo "IBM Cloud Pak for Applications 5.1 - L-AMIK-BYM26G" > ./.license_accepted;;
7) touch ./.license_accepted
   echo "IBM Cloud Pak for Applications Limited Edition 5.1 - L-AMIK-BYM2RQ" > ./.license_accepted;;
8) touch ./.license_accepted
   echo "IBM WebSphere Application Server for z/OS 8.5.5 - L-CTUR-C7K3YZ" > ./.license_accepted;;
9) touch ./.license_accepted
   echo "IBM WebSphere Application Server for z/OS 9.0.5 -L-CTUR-CBPUER"> ./.license_accepted;;

   esac

}
