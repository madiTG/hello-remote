#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"


###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi

### Get the TA Docker Container IDs

trans=$(docker ps -a | grep transformation-advisor-server | awk '{print $1}')
couch=$(docker ps -a | grep transformation-advisor-db | awk '{print $1}')
ui=$(docker ps -a | grep transformation-advisor-ui | awk '{print $1}')
graph=$(docker ps -a | grep transformation-advisor-neo4j | awk '{print $1}')

#### Rename Docker Name ########

docker rename $trans taserver
docker rename $couch tadb
docker rename $ui taui
docker rename $graph tagraph
