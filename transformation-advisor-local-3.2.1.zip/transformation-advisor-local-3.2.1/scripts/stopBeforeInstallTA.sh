#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

#run scripts at relative path
scriptdir="$(dirname "$0")"
cd "$scriptdir"

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi


#### Clean up docker ########
#############################

### Get the TA Docker Container IDs

ui=$(docker ps -a | grep transformation-advisor-ui | awk '{print $1}')
couch=$(docker ps -a | grep transformation-advisor-db | awk '{print $1}')
server=$(docker ps -a | grep transformation-advisor-server | awk '{print $1}')
neo4j=$(docker ps -a | grep transformation-advisor-neo4j | awk '{print $1}')

#### Stop All TA Docker Containers

for a in $ui; do
	docker stop $a
done

for b in $couch; do
	docker stop $b
done

for c in $server; do
	docker stop $c
done

for d in $neo4j; do
        docker stop $d
done


sleep 5

### Find the hostname and edit the environment files #######
############################################################

source ./findHost.sh
replaceHost

sleep 5
