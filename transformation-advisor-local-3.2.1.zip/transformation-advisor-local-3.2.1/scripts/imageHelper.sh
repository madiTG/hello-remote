#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

# source configure before installing
TA_LOCAL_CONFIG=./.configuration
TA_LOCAL_CONFIG_DEV=./.configuration.dev

# if there is dev file, use it
if [ -f "$TA_LOCAL_CONFIG_DEV" ]; then
  echo "$TA_LOCAL_CONFIG_DEV is provided. Using dev file."
  source "$TA_LOCAL_CONFIG_DEV"
else
  source "$TA_LOCAL_CONFIG"
fi

###create the podman/docker alias
if [[ $TA_LOCAL_TEMP_PODMAN_INSTALL = true ]]; then
  shopt -s expand_aliases
  source ./.podman_config
fi


source ./.security_config


function imagePull {
	docker pull "${TA_LOCAL_CONFIG_COUCH_IMAGE}" #>../logs/PullinggraphDB_$(date +"%Y%m%d_%H%M%S").log
	docker pull "${TA_LOCAL_CONFIG_SERVER_IMAGE}" #>../logs/PullingcouchDB_$(date +"%Y%m%d_%H%M%S").log
	docker pull "${TA_LOCAL_CONFIG_UI_IMAGE}" #>../logs/PullingserverDB_$(date +"%Y%m%d_%H%M%S").log
	docker pull "${TA_LOCAL_CONFIG_NEO4J_IMAGE}" #>../logs/PullinguiDB_$(date +"%Y%m%d_%H%M%S").log
}

function imageRun {

# we prioritise to use docker if available
if [[ $TA_LOCAL_TEMP_DOCKER_INSTALL = true ]]; then

	if uname -s | grep 'Darwin' >/dev/null; then
		# sed commands modified for mac
		sed -i '' -e  's/<contServer>/taserver/g' .env
		sed -i '' -e  's/<contUI>/taui/g' .env
		sed -i '' -e  's/<contDB>/tadb/g' .env
		sed -i '' -e  's/<contGraph>/tagraph/g' .env
                sed -i '' -e 's/<internal_port>/'${TA_LOCAL_INTERNAL_SERVER_PORT}'/g' .env
		sed -i '' -e 's/<server_port>/'${TA_EXTERNAL_PORT_SERVER}'/g' .env
	else
		sed -i 's/<contServer>/taserver/g' .env
		sed -i 's/<contUI>/taui/g' .env
		sed -i 's/<contDB>/tadb/g' .env
		sed -i 's/<contGraph>/tagraph/g' .env
                sed -i 's/<internal_port>/'${TA_LOCAL_INTERNAL_SERVER_PORT}'/g' .env
		sed -i 's/<server_port>/'${TA_EXTERNAL_PORT_SERVER}'/g' .env
	fi
	docker network create ta_local 
	docker run  -d --expose ${TA_LOCAL_INTERNAL_DB_PORT}  --net ta_local --name tadb --memory="${TA_LOCAL_CONFIG_COUCH_MEMORY}" --cpus="${TA_LOCAL_CONFIG_COUCH_CPU}" --env-file ./.env -v "$(pwd)/../data:/opt/couchdb/data:Z" "${TA_LOCAL_CONFIG_COUCH_IMAGE}" #2>/dev/null

	docker run  -d -p ${TA_LOCAL_INTERNAL_UI_PORT}:${TA_LOCAL_INTERNAL_UI_PORT} --net ta_local --name taui --memory="${TA_LOCAL_CONFIG_UI_MEMORY}" --cpus="${TA_LOCAL_CONFIG_UI_CPU}" --env-file ./.env "${TA_LOCAL_CONFIG_UI_IMAGE}" #2>/dev/null

	docker run  -d -p ${TA_EXTERNAL_PORT_SERVER}:${TA_LOCAL_INTERNAL_SERVER_PORT} --net ta_local --name taserver  --memory="${TA_LOCAL_CONFIG_SERVER_MEMORY}" --cpus="${TA_LOCAL_CONFIG_SERVER_CPU}" --env-file ./.env "${TA_LOCAL_CONFIG_SERVER_IMAGE}" #2>/dev/null

	docker run  -d --expose 7687 --net ta_local --name tagraph --memory="${TA_LOCAL_CONFIG_NEO4J_MEMORY}" --cpus="${TA_LOCAL_CONFIG_NEO4J_CPU}" --env-file ./.env -v "$(pwd)/../graph_data:/data:Z" "${TA_LOCAL_CONFIG_NEO4J_IMAGE}" #2>/dev/null
else
	if uname -s | grep 'Darwin' >/dev/null; then
		# sed commands modified for mac
		sed -i '' -e  's/<contServer>/localhost/g' .env
		sed -i '' -e  's/<contUI>/localhost/g' .env
		sed -i '' -e  's/<contDB>/localhost/g' .env
		sed -i '' -e  's/<contGraph>/localhost/g' .env
                sed -i '' -e 's/<internal_port>/'${TA_LOCAL_INTERNAL_SERVER_PORT}'/g' .env
		sed -i '' -e 's/<server_port>/'${TA_EXTERNAL_PORT_SERVER}'/g' .env
	else
		sed -i 's/<contServer>/localhost/g' .env
		sed -i 's/<contUI>/localhost/g' .env
		sed -i 's/<contDB>/localhost/g' .env
		sed -i 's/<contGraph>/localhost/g' .env
                sed -i 's/<internal_port>/'${TA_LOCAL_INTERNAL_SERVER_PORT}'/g' .env
		sed -i 's/<server_port>/'${TA_EXTERNAL_PORT_SERVER}'/g' .env
	fi

	podman pod create -n ta_pod -p ${TA_LOCAL_INTERNAL_UI_PORT}:${TA_LOCAL_INTERNAL_UI_PORT} -p ${TA_EXTERNAL_PORT_SERVER}:${TA_LOCAL_INTERNAL_SERVER_PORT}

	podman run  -d --pod ta_pod --name tadb --env-file ./.env -v "$(pwd)/../data:/opt/couchdb/data:Z" "${TA_LOCAL_CONFIG_COUCH_IMAGE}"

	podman run  -d --pod ta_pod --name tagraph --env-file  ./.env -v "$(pwd)/../graph_data:/data:Z"  "${TA_LOCAL_CONFIG_NEO4J_IMAGE}"

	podman run -d --pod ta_pod --name taserver  --env-file ./.env "${TA_LOCAL_CONFIG_SERVER_IMAGE}"

	podman run -d --pod ta_pod --name taui  --env-file ./.env "${TA_LOCAL_CONFIG_UI_IMAGE}"

fi

}

function startTA {

### Get the TA Docker Container IDs

ui=$(docker ps -a | grep transformation-advisor-ui | awk '{print $1}')
couch=$(docker ps -a | grep transformation-advisor-db | awk '{print $1}')
server=$(docker ps -a | grep transformation-advisor-server | awk '{print $1}')
neo4j=$(docker ps -a | grep transformation-advisor-neo4j | awk '{print $1}')

### start containers

docker start $couch
sleep 10
docker start $server
docker start $ui
docker start $neo4j

}


