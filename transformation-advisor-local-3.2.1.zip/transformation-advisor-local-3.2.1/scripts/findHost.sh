#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

# modified by Huang, Fuguo (aka ken) on 08.03.2021.
# replace the <host> in env file
# source the TA_LOCAL_RUNTIME_HOST_IP=<host/ip> in the environment variables at installation time

function getHostIp() {
	ta_temp_host=localhost

	if uname -s | grep 'Darwin' >/dev/null; then
    #	macOS
		# If variable not set or null, use default en0.
		temp_ta_local_host_network_interface=${TA_LOCAL_HOST_NETWORK_INTERFACE:-en0}
		temp_ta_local_host=$(ipconfig getifaddr ${temp_ta_local_host_network_interface})
		if [ ! -z "$temp_ta_local_host" ]; then
			# not empty
			ta_temp_host=${temp_ta_local_host}
		fi
	elif  [[ -d  "/mnt/c/" ]] ; then
	       ta_temp_host=localhost
#windows
       else
  	# Red Hat Linux
		host=$(hostname -f)

		if [ "$host" != "${host/./}" ]; then
			host=$(hostname -f)
		else
			host=$(ip route get 8.8.8.8 | awk -F"src " 'NR==1{split($2,a," ");print a[1]}')
		fi

		ta_temp_host=${host}
  fi

	export TA_LOCAL_RUNTIME_HOST_IP=${ta_temp_host}
}

function replaceHost() {
	getHostIp
	if uname -s | grep 'Darwin' >/dev/null; then
		#	macOS
		sed -i '' -e 's/<host>/'$TA_LOCAL_RUNTIME_HOST_IP'/g' ./.env
	else
		# Red Hat Linux and windows
		sed -i 's/<host>/'${TA_LOCAL_RUNTIME_HOST_IP}'/g' ./.env
	fi
}
