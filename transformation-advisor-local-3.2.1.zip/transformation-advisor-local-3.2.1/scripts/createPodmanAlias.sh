#!/usr/bin/env bash

# ---------------------------------------------
# Licensed Materials - Property of IBM
# (C) Copyright IBM Corporation 2021
# ---------------------------------------------

# 1. we run this once to get the variables
# 2. we source the alias from a file
function createPodmanAlias {

	if [[ $TA_LOCAL_TEMP_RUN_ONLY_ONCE_PODMAN_ALIAS_FLAG = true ]]; then
		return
	fi

	podRun=$(which podman 2>&1)

	#if [[  -z "$podRun" || ! $podRun =~ "no podman in" ]] ; then
		# if docker is installed, we use docker
		# if podman is installed, we use podman and alias docker to podman
		# if non of these are installed, we stop here

		checkDocker=$(docker ps 2>&1)
		# we prioritise to use docker if available
		# if does not contain "command not found", we have docker
		if [[ ! $checkDocker =~ "command not found" && ! $checkDocker =~ "not be found" ]]; then
			export TA_LOCAL_TEMP_DOCKER_INSTALL=true
			export TA_LOCAL_TEMP_RUN_ONLY_ONCE_PODMAN_ALIAS_FLAG=true

			return
		fi

		checkPodman=$(podman ps 2>&1)

		if [[ ! $checkPodman =~ "command not found" ]]; then
			export TA_LOCAL_TEMP_PODMAN_INSTALL=true
			export TA_LOCAL_TEMP_RUN_ONLY_ONCE_PODMAN_ALIAS_FLAG=true

			shopt -s expand_aliases
			alias docker='podman'
			return
		fi

		if [[ $checkPodman =~ "command not found" ]] && [[ $checkDocker =~ "command not found" ]] ; then
			echo "Install docker or podman before proceeding to install Transformation Advisor."
			echo "https://www.ibm.com/docs/en/cta?topic=started-non-ocp-install"
			echo ""
			exit
		elif [[ $checkDocker =~ "Cannot connect to the Docker daemon" ]] ; then
			echo "Docker installed but not running. Please start docker or check that your user is a member of the docker group"
			echo "create docker group (groupadd docker)"
			echo "restart docker service (service docker restart)"
			echo "add user to docker group (usermod -a -G docker <user>)"
			exit
		fi

	#fi

}






